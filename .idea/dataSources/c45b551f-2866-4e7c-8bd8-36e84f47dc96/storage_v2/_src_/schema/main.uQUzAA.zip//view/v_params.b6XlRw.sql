CREATE VIEW v_params AS select ts.section,
                               pa.key,
                               case WHEN pa.value is null THEN pa.defaut ELSE pa.value END as value
                        from t_params pa
                                 INNER JOIN t_section ts on pa.fk_section = ts.id;

