CREATE VIEW v_culture as
SELECT lg.english, cu.code
FROM t_culture cu
         INNER JOIN t_lang lg
                    on lg.id = cu.id;

